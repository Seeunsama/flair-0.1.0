# Tutorial 4: Text Embeddings

Text embeddings are different from [word embeddings](/resources/docs/TUTORIAL_WORD_EMBEDDING.md) in that they give you one embedding for an entire text, whereas word embeddings give you embeddings for individual words. 

For this tutorial, we assume that you're familiar with the [base types](/resources/docs/TUTORIAL_BASICS.md) of this library and how
   [word embeddings](/resources/docs/TUTORIAL_WORD_EMBEDDING.md) work.

# TODO



## Next 

You can now either look into the tutorial about [training your own models](/resources/docs/TUTORIAL_TRAINING_A_MODEL.md). 